def resize(image, output_shape):
    raise NotImplementedError
